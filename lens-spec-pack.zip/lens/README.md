# Lens: project spec pack for Claude Code

Working name **Lens** (placeholder). An AI news comparison platform for India, in the Ground News pattern: clustered stories, coverage bar, blindspots, per-story source lists. Adapted with cross-lingual coverage, an India stance axis, claim-level fact-check links, and a cited Ask interface.

This folder is the spec. Claude Code builds from it.

## How to use

1. Create a new repo and copy this folder's contents to the root.
2. Open Claude Code in the repo. It reads `CLAUDE.md` automatically.
3. Paste the kickoff prompt for Phase 0 from `docs/12_BUILD_PLAN.md`.
4. Finish each phase's acceptance criteria before starting the next.
5. Keep humans in the loop for: sources and ratings evidence, eval labels, legal review, and the open decisions in `docs/01_PRODUCT.md`.

## Files

| File | Contents |
|---|---|
| `CLAUDE.md` | Non-negotiable rules, stack, repo layout, commands, workflow |
| `docs/01_PRODUCT.md` | Vision, features, India adaptation, open decisions |
| `docs/02_ARCHITECTURE.md` | Two-graph architecture, model tiers, infra, failure behavior |
| `docs/03_DATA_MODEL.md` | Postgres DDL, Qdrant collections, retention |
| `docs/04_INGESTION_AND_CLUSTERING.md` | Offline pipeline, chunking, clustering, stance |
| `docs/05_RETRIEVAL.md` | Hybrid search, ColBERT rerank, source balancing, ablation |
| `docs/06_AGENTS_AND_SCHEMAS.md` | Online graph, state, Pydantic schemas, prompts and skills |
| `docs/07_GUARDRAILS.md` | Guard catalog with IDs, tracing, India-specific output checks |
| `docs/08_EVALS_LLMOPS.md` | Datasets, metrics, judge, CI gate, LangSmith, release |
| `docs/09_API_SPEC.md` | Endpoints, JSON shapes, SSE events |
| `docs/10_UI_SPEC.md` | Ground News-style UI: tokens, pages, components, copy, a11y |
| `docs/11_MEMORY.md` | Memory layers and strict personalization rules (Phase 9) |
| `docs/12_BUILD_PLAN.md` | Phases, acceptance criteria, kickoff prompts |
| `docs/13_INDIA_SOURCES.md` | Source selection, ratings approach, stance rubric |
| `data/sources/sources.seed.yaml` | Seed template with `TO_VERIFY` fields |

## Things this pack deliberately does not do

- It does not contain feed URLs, ownership facts, or outlet ratings. Those need verified evidence.
- It does not pin library or model versions. Claude Code checks current docs and pins them.
- Thresholds (clustering, retrieval, eval gates) are starting values to tune on your own labeled data.
- It is not legal advice. Licensing, ratings publication, and sensitive-content handling need legal review before public launch.
